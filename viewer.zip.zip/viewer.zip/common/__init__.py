# Common utilities for Remote Desktop application
